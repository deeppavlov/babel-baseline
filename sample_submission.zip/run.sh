#!/bin/sh

cd /en-de

./translate.sh

